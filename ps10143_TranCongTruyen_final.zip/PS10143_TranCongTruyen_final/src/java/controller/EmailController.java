/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Email;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Transactional
@Controller
@RequestMapping("/email/")
public class EmailController {

    @Autowired
    ServletContext context;

    @Autowired
    JavaMailSender mailSender; //1. đối tượng gửi mail

    @RequestMapping(value = "index", method = RequestMethod.GET)
    public String showForm(ModelMap model) {
        model.addAttribute("mail", new Email());
        return "email/index";
    }

    @RequestMapping(value = "SendEmail", method = RequestMethod.POST)
    public String sendWithAttach(ModelMap model,
            @ModelAttribute("mail") Email mailInfo
    ) {
        try {
            //2. tạo 1 đối tượng MimeMessage
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            //từ mail nào gửi đi
            helper.setFrom(mailInfo.getFrom());
            //gửi đêna mail nào
            helper.setTo(mailInfo.getTo());
            //tiêu đề của mail
            helper.setSubject(mailInfo.getSubject());
            //nội dung mail
            helper.setText(mailInfo.getBody());
            //gửi mail đi
            mailSender.send(message);
        } catch (Exception e) {

            // thông báo lỗi qua trang SendEmail
            model.addAttribute("error", e.getMessage());
            return "email/SendEmail";
        }

        return "email/SendEmail";
    }

}
