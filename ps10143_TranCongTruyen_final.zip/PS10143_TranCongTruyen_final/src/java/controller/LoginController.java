/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Account;
import javax.transaction.Transactional;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Transactional
@Controller
public class LoginController {

    @Autowired
    SessionFactory factory;

    @RequestMapping(value = "login", method = RequestMethod.GET)
    public String login(ModelMap model) {
        model.addAttribute("account", new Account());
        return "login";
    }

    @RequestMapping("login")
    public String login(ModelMap model, @ModelAttribute("account") Account account) {
        Session session = factory.getCurrentSession();
            String hql = "FROM Account where username='" + account.getUsername() + "'";
            Query query = session.createQuery(hql);
            Account acc = (Account) query.list().get(0);
            if(acc.getPassword().equals(account.getPassword())) {
               return "index";
            }
            else {
                 model.addAttribute("message", "Sai mật khẩu");
                 return "login";
            }
    }

}
