/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Depart;
import entity.Record;
import java.util.List;
import javax.transaction.Transactional;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Transactional
@Controller
@RequestMapping("/record/")
public class RecordController {

    @Autowired
    SessionFactory factory;

    @RequestMapping("index")
    public String index(ModelMap model, @RequestParam("page") String getpage) {

        Session session = factory.getCurrentSession();
        String hql_sum = "Select count(RecordID)FROM Record ";
        Query query_sum = session.createQuery(hql_sum);
        long tong = (long) query_sum.uniqueResult();

        long pages = Integer.parseInt(getpage), maxResult = 8;
        long indexrow = pages * maxResult - maxResult;
        long totalpage = (long) Math.ceil((double) tong / maxResult);

        String hql = "from Record"; // lấy hết các tài khoản ra
        Query query = session.createQuery(hql);
        query.setFirstResult((int) indexrow);
        query.setMaxResults((int) maxResult);
        List<Record> list = query.list();
        model.addAttribute("records", list); // lấy danh sách tài khoản list đưa vào thuộc tính users
        model.addAttribute("totalpage", totalpage);
        model.addAttribute("pages", pages);
        return "record/index";
    }

    //1. trang insert hiện thị lên đầu tiên
    @RequestMapping(value = "insert", method = RequestMethod.GET)
    public String insert(ModelMap model) {
        model.addAttribute("record", new Record());
        return "record/insert";
    }

    //2. khi click insert thì chạy hàm này
    @RequestMapping(value = "insert", method = RequestMethod.POST)
    public String insert(ModelMap model, @ModelAttribute("record") Record record) {
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();
        String sql = "insert into Record (RecordType, StaffID) values('" + record.isRecordType() + "','" + record.getStaffID() + "')"; // lấy hết các tài khoản ra
        try {
            Query query = session.createSQLQuery(sql);
            query.executeUpdate();
            t.commit();  // 2. commit nếu thêm thành công
            model.addAttribute("message", "Thêm mới thành công !");
        } catch (Exception e) {
            t.rollback();  // 3. rollback nếu thêm thất bại
            model.addAttribute("message", "Thêm mới thất bại !");
        } finally {
            session.close();
        }
        return "redirect:index.htm?page=1"; //4. qua trang index hiện các tài khoản ra
    }

    @RequestMapping("delete")
    public String delete(ModelMap model, @RequestParam("recordID") int recordID) {
        Session session = factory.getCurrentSession();
        Record record = (Record) session.get(Record.class, recordID);
        session.delete(record);
        return "redirect:index.htm?page=1";
    }
}
