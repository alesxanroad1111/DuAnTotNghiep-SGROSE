/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Record")
public class Record  implements Serializable{
    
    @Id
    private int recordID; // khóa chính
    private boolean recordType;
    private int staffID;

    public Record() {
    }

    public Record(boolean recordType, int staffID) {
        this.recordType = recordType;
        this.staffID = staffID;
    }

    public int getRecordID() {
        return recordID;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

    public boolean isRecordType() {
        return recordType;
    }

    public void setRecordType(boolean recordType) {
        this.recordType = recordType;
    }

    public int getStaffID() {
        return staffID;
    }

    public void setStaffID(int staffID) {
        this.staffID = staffID;
    }
   
}
