package entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



//1 tự viết thì code đẹp

@Entity
@Table(name = "Depart")
public class Depart {

    @Id
    private String departID; // khóa chính
    private String name;
    private String depImg;
    private boolean delStatus;

    public Depart() {
    }

    public Depart(String departID, String name, String depImg, boolean delStatus) {
        this.departID = departID;
        this.name = name;
        this.depImg = depImg;
        this.delStatus = delStatus;
    }

    public String getDepartID() {
        return departID;
    }

    public void setDepartID(String departID) {
        this.departID = departID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepImg() {
        return depImg;
    }

    public void setDepImg(String depImg) {
        this.depImg = depImg;
    }

    public boolean isDelStatus() {
        return delStatus;
    }

    public void setDelStatus(boolean delStatus) {
        this.delStatus = delStatus;
    }

    
}
