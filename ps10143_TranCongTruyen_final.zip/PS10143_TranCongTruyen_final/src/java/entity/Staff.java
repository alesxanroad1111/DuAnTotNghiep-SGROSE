package entity;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;




//1 tự viết thì code đẹp

@Entity
@Table (name = "Staff")
public class Staff implements Serializable{

    @Id
    private int staffID;
    private  String staffName;
    private String departID;

    public Staff() {
    }

    public Staff(String staffName, String departID) {
        this.staffName = staffName;
        this.departID = departID;
    }

    public int getStaffID() {
        return staffID;
    }

    public void setStaffID(int staffID) {
        this.staffID = staffID;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getDepartID() {
        return departID;
    }

    public void setDepartID(String departID) {
        this.departID = departID;
    }

    
    
}
