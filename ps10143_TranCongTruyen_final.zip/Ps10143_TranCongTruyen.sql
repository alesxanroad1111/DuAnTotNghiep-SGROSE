﻿﻿use master
go
drop database masv_hoten_java5
go
create database masv_hoten_java5
go
use masv_hoten_java5
go

create table Account
(
	username varchar(50) primary key,
	password varchar(50)
)
go
insert into Account values('admin','123')
go
select * from Account
go


create table [Users]
(
	Username varchar(50) primary key,
	[Password] varchar(50),
	Fullname Nvarchar(50),
	img varchar(50)
)
go
create table Depart
(
	DepartID varchar(20) primary key,
	Name Nvarchar(50),
	DepImg varchar(50),
	DelStatus bit
)
go
create table Staff
(
	StaffID int identity(1,1) primary key,
	StaffName Nvarchar(50),
	Gender bit,
	Birthday date,
	Photo varchar(50),
	Email varchar(50),
	Salary float,
	Notes Nvarchar(50),
	DepartID varchar(20),
	Deleted bit
)
go
create table Record
(
	RecordID int identity(1,1) primary key,
	RecordType bit,
	RecordDate date,
	StaffID int references Staff(StaffID)
)
go
--2. thêm dữ liệu vào
--Bước 1 thêm bảng User, Depart
--Bước 2 Staff
--Bước 3 Record


insert into [Users] values('phuc','123',N'hoàng phúc','phuc.jpg')
go
insert into [Users] values('thanh','123',N'quang thành','thanh.jpg')
go
insert into [Users] values('loc','123',N'thành lộc','loc.jpg')
go
insert into [Users] values('cuongml','123',N'cuongoccho','cuong.jpg')
go
insert into [Users] values('vu','123',N'vũ heo','vu.jpg')
go


insert into Depart values('DP01',N'Nhân sự','nhansu.jpg',0)
go
insert into Depart values('DP02',N'Sales','sales.jpg',1)
go
insert into Depart values('DP03',N'Kho','kho.jpg',0)
go
insert into Depart values('DP04',N'Thiết kế','thietke.jpg',1)
go
insert into Depart values('DP05',N'Kinh doanh','kinhdoanh.jpg',0)
go



insert into Staff values(N'Thành',1,'11/10/1995','thanh.jpg','thanh@fpt.edu.vn',10000000,'','DP01',1)
go
insert into Staff values(N'Lộc',0,'15/10/1995','loc.jpg','loc@fpt.edu.vn',20000000,'','DP01',1)
go
insert into Staff values(N'Cương',1,'1/8/1995','cuong.jpg','cuong@fpt.edu.vn',200000,'','DP02',0)
go
insert into Staff values(N'Vũ',1,'3/7/1997','vu.jpg','vu@fpt.edu.vn',7000000,'','DP02',1)
go
insert into Staff values(N'Kỳ',1,'12/3/1995','ky.jpg','ky@fpt.edu.vn',6000000,'','DP03',1)
go
insert into Staff values(N'Đông',0,'16/12/1995','dong.jpg','dong@fpt.edu.vn',4000000,'','DP03',1)
go
insert into Staff values(N'Trọng',1,'4/10/1995','trong.jpg','trong@fpt.edu.vn',15000000,'','DP04',1)
go
insert into Staff values(N'Tình',1,'17/6/1995','tinh.jpg','tinh@fpt.edu.vn',1400000,'','DP04',1)
go
insert into Staff values(N'Hùng',1,'21/10/1995','hung.jpg','hung@fpt.edu.vn',21000000,'','DP05',1)
go
insert into Staff values(N'Bảo',1,'22/2/1995','bao.jpg','bao@fpt.edu.vn',20000000,'','DP05',1)
go


insert into Record values(1,'6/12/2019',1)
go
insert into Record values(0,'5/12/2019',2)
go
insert into Record values(1,'4/12/2019',3)
go
insert into Record values(1,'3/12/2019',4)
go
insert into Record values(1,'2/12/2019',5)
go
insert into Record values(0,'1/12/2019',6)
go
insert into Record values(1,'1/12/2019',7)
go
insert into Record values(1,'2/12/2019',8)
go
insert into Record values(1,'2/12/2019',9)
go
insert into Record values(1,'2/12/2019',10)
go
select * from [Users]
go
select * from depart
go
select * from Staff
go
select * from Record
go
select * from Account
go
